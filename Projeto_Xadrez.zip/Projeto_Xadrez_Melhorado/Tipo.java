
/**
 * Enumeration class TipoPeca - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Tipo
{
    REI, RAINHA, TORRE, BISPO, CAVALO, PEAO
}
